package parking;

import java.time.LocalDateTime;
import java.util.Scanner;

public class Parking {

	public final static int CAPACIDAD = 50;

	public Vehiculo[] plazas = new Vehiculo[CAPACIDAD];

	/**
	 * recorre todo el array inicializando todos los atributos del vehiculo.
	 */
	private void inicializar() {
		
		for(Vehiculo vh:plazas) {
			vh=null;
		}

	}

	public Parking() {
		inicializar();// Construye un nuevo banco de datos.

	}

	/**
	 * Comprueba si hay plazas libres en el parking.
	 * 
	 * @return
	 */
	public boolean hayPlazasLibres() {
		boolean plazasLibres = false;
		for (Vehiculo plazas : plazas) {
			if (plazas == null) {
				plazasLibres = true;
			}
		}
		return plazasLibres;
	}

	/**
	 * Añade un nuevo vehículo al parking siempre que haya disponibilidad.
	 * 
	 * @param vh = vehiculo que entra en el parking.
	 * @return número de plaza donde se aparca el coche. Si no se aparca, devuelve -1.
	 */
	public int addVehiculoToParking(Vehiculo vh) {
		int retorno = -1;
		
		if (hayPlazasLibres()) {
			// posicionar plaza.
			for (int posicion = 0; posicion < plazas.length && retorno==-1; posicion++) {
				if (plazas[posicion] == null) {
					plazas[posicion] = vh;
					retorno = posicion;
				}
			}
		}
		return retorno;
	}

	public void sacarVehiculo(String matricula) {
		for (int i = 0; i < plazas.length; i++) {
			if (plazas[i].getMatricula().equalsIgnoreCase(matricula)) {
				plazas[i] = null;
			}

		}

	}
	
	public void mostrarVehiculos () {
		
		for (int i = 0; i < plazas.length; i++) {
			if(plazas[i]!=null) {
				System.out.println(plazas[i]);
			}
		}
		
	}
	
	public void ordenarMatricula () {
		      Vehiculo aux;
		      boolean esta_ordenado = false;
		      
		      while (esta_ordenado == false){
			    esta_ordenado = true; 
			            
			    for (int i = 0; i<plazas.length; i++)
			    {
				if(plazas[i].compareTo(plazas[i+1] == -1)
				{
				    // Si entra aquí, es porque estos elementos están desordenados
				    aux = plazas[i];
				    plazas[i] = plazas[i+1];
				    plazas[i+1] = aux;
				    // Lo señalo, he tenido que ordenar estos dos elementos, esto no
				    // habría sido necesario si el array ya estuvira ordenado
				    esta_ordenado = false;
				}
			    }
		      }
		}
	

	public int compararVehiculos(Vehiculo v1, Vehiculo v2) {
	
		return v1.getMatricula().compareTo(v2.getMatricula());
		
	}
			
		
				
	
	

	/*
	 * public Vehículo mostrarVehiculosOrdenadosPorFecha() {
	 * 
	 * return ""; }
	 */

	public String mostrarVehiculosOrdenadosPorMarcaYModelo() {
		return "";
	}

	public String mostrarVehiculosOrdenadosPorTipoYCombustible() {
		return "";
	}

	public String mostrarVehiculosOrdenadosPorMatricula() {
		return "";
	}

	/* El profe no nos deja poner Syso en las Clases. Debemos usar el Main */
	/*
	 * public Vehiculo pideVehiculo() { // pedir los datos del vehiculo en el main.
	 * Scanner sc = new Scanner(System.in); String marca, modelo, matricula;
	 * System.out.print("marca: "); marca = sc.nextLine(); modelo = sc.nextLine();
	 * matricula = sc.nextLine();
	 * 
	 * Vehiculo vh = new Vehiculo();
	 */
}
