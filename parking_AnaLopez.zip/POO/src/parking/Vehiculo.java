package parking;

import java.time.LocalDateTime;

import parking.excepciones.MatriculaNoValida;

public class Vehiculo implements Comparable<Vehiculo> {

	private String marca;
	private String modelo;
	private String matricula;
	private Combustible combustible;
	private LocalDateTime fechaEntrada;
	private TipoVehiculo tipovehiculo;

	
	/**
	 * @param marca
	 * @param modelo
	 * @param matricula
	 * @param combustible
	 * @param fechaEntrada
	 * @param tipovehiculo
	 * @throws Exception 
	 */
	public Vehiculo(String marca, String modelo, String matricula, String combustible, LocalDateTime fechaEntrada,
			String tipovehiculo) {
		if (validarMatricula(matricula)) {
			// super(); //no es necesario
			this.marca = marca;
			this.modelo = modelo;
			this.matricula = matricula;
			setCombustible(combustible);
			this.fechaEntrada = fechaEntrada;
			setTipovehiculo(tipovehiculo);
		} else {
			
		}
	}
	
	public String getMarca() {
		return marca;
	}

	

	public String getModelo() {
		return modelo;
	}

	

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) throws MatriculaNoValida  {
		if(validarMatricula(matricula)) {
			this.matricula=matricula;
		}else {
			throw new MatriculaNoValida();
			
		}
	}

	public Combustible getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		if(Combustible.valueOf(combustible.toUpperCase())!=null) {
			this.combustible=Combustible.valueOf(combustible.toUpperCase());
		}
	}

	public LocalDateTime getFechaEntrada() {
		return fechaEntrada;
	}

	public void setFechaEntrada(LocalDateTime fechaEntrada) {
		this.fechaEntrada = fechaEntrada;
	}

	public TipoVehiculo getTipovehiculo() {
		return tipovehiculo;
	}

	public void setTipovehiculo(String tipovehiculo) {
		if(TipoVehiculo.valueOf(tipovehiculo.toUpperCase())!=null){
			this.tipovehiculo=TipoVehiculo.valueOf(tipovehiculo.toUpperCase());
		}
	}

	/**
	 * Devuelve true sin la matrícula es válida: 4 alfanuméricos y 4 numéricos.
	 * 
	 * @param matricula
	 * @return
	 * 
	 * 
	 * 
	 */
	
	private boolean validarMatricula(String matricula) {
		boolean valida = false;
		int contDig = 0;
		
		

		if (matricula.length() == 8) {
		for (int i = 0; i <= matricula.length()-1; i++) {
			if(Character.isDigit(matricula.charAt(i))) {
				contDig++;
			}
				
			if(contDig==4) {
				valida=true;
			}
		}
		}
		return valida;
	}
	
	
				
			
	/*public void mostrarVehiculos() {
		
		System.out.println(this.marca + " " + " " + this.modelo + " " + this.matricula + " " + this.combustible + "  "
				+ this.fechaEntrada + " " + this.tipovehiculo);
		
	}*/

	/*He puesto un ToString porque el profe nos pide que lo pongamos*/
	public String toString() {
		return "El vehículo marca " + marca + ", modelo " + modelo + ", con  matricula " + matricula + ", utiliza combustible "
				+ combustible + ". Tiene fecha de entrada al parking " + fechaEntrada + " y es un vehículo tipo " + tipovehiculo;
	}

	@Override
	//Permite comparar este vehículo con otro.
	//Por defecto utilizamos la matrícula para realizar la comparación.
	
	public int compareTo(Vehiculo otroCoche) {
		
		return getMatricula().compareTo(otroCoche.getMatricula());
	}
			
			
			
			

		
	}
	
	
	

			
				
			
			
			
	
					
				
				
				
				
				

