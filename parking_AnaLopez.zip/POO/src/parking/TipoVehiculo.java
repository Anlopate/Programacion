package parking;

public enum TipoVehiculo {
	
	AUTOMOVIL, CICLOMOTOR, TRANSNMERCANCIAS, TRANSCOLECTIVO;

}
