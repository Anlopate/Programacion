package parking;

public enum Combustible {
	
	ELECTRICO, GASOIL, GASOLINA, HIBRIDO;

}
