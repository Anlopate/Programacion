package parking.excepciones;

public class MatriculaNoValida extends Exception {
	
	private final static String MENSAJE="La matrícula no es válida.";

	public MatriculaNoValida() {
		super(MENSAJE);
	}

}
