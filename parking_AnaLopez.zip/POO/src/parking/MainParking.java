package parking;

import java.time.LocalDateTime;
import java.util.Scanner;



public class MainParking {
	public static void main(String[] args) {
		
		Parking canalejas = new Parking();
		

		Vehiculo peugeot = new Vehiculo ("Peugeot", "307","6739DYXZ","Gasoil",LocalDateTime.now(), "automovil");
		canalejas.addVehiculoToParking(peugeot);
		
		Vehiculo seat = new Vehiculo ("seat", "307","1234SDFG","Gasolina",LocalDateTime.now(), "automovil");
		canalejas.addVehiculoToParking(seat);
		Vehiculo audi = new Vehiculo ("audi", "c4","7654ABCD","electrico",LocalDateTime.now(), "automovil");
		canalejas.addVehiculoToParking(audi);
		Vehiculo bmw = new Vehiculo ("bmw", "250","1234ABCD","Gasoil",LocalDateTime.now(), "automovil");
		canalejas.addVehiculoToParking(bmw);
		Vehiculo opel = new Vehiculo ("opel", "vectra","6739DYXZ","Gasoil",LocalDateTime.now(), "automovil");
		canalejas.addVehiculoToParking(opel);
		
		canalejas.mostrarVehiculos();
		
		
		
		
		
		System.out.println(canalejas);
		System.out.println(peugeot.toString());
		
	}




}